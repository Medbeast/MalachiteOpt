# MalachiteOpt APK — Build Instructions

## Option A: Android Studio (easiest)
1. Install Android Studio: https://developer.android.com/studio
2. Open this folder as a project
3. Let Gradle sync finish
4. Build → Build Bundle(s)/APK(s) → Build APK(s)
5. APK at: app/build/outputs/apk/debug/app-debug.apk

## Option B: Command line (Linux/macOS)
```bash
# Requires: JDK 17+, Android SDK
export ANDROID_HOME=~/Android/Sdk   # adjust to your SDK path
./gradlew assembleDebug
# APK at: app/build/outputs/apk/debug/app-debug.apk
```

## Option C: GitHub Actions (no local setup)
Push to GitHub → add this workflow → APK built in cloud:
.github/workflows/build.yml
```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-java@v3
        with: { java-version: '17', distribution: 'temurin' }
      - run: chmod +x gradlew && ./gradlew assembleDebug
      - uses: actions/upload-artifact@v3
        with:
          name: MalachiteOpt-debug.apk
          path: app/build/outputs/apk/debug/app-debug.apk
```

## How the APK works
- Loads the full WebUI (index.html) from app assets
- Injects a JavaScript shim that replaces the KernelSU `ksu` object
- `ksu.exec(cmd, cb)` calls → Java RootBridge → `su -c cmd` → cb(exit, stdout, stderr)
- All existing WebUI code works unchanged — Clear RAM, Dalvik, Apply config, etc.
- Requires a rooted device (Magisk or KernelSU)

## Grant root on first launch
When prompted by Magisk/KernelSU, tap **Grant** for com.malachite.optimizer
