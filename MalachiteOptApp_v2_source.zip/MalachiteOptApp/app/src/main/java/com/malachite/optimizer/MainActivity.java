package com.malachite.optimizer;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * MalachiteOpt v2.0 — Root Bridge Activity
 *
 * Loads the WebUI from assets and exposes a JavaScript interface
 * that mimics the KernelSU ksu.exec() API used in the module WebUI.
 *
 * The JS bridge: window.NativeBridge.exec(cmd, callbackId)
 * On completion calls back: window.nativeCb(callbackId, exitCode, stdout, stderr)
 */
public class MainActivity extends Activity {

    private WebView webView;
    private final ExecutorService executor = Executors.newCachedThreadPool();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);

        // ── WebView settings ──────────────────────────────────────────────────
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccessFromFileURLs(true);
        ws.setAllowUniversalAccessFromFileURLs(true);
        ws.setCacheMode(WebSettings.LOAD_NO_CACHE);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        // ── Clients ───────────────────────────────────────────────────────────
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                // Inject KSU compatibility shim so existing ksu.exec() calls
                // in the WebUI are automatically redirected to our bridge
                injectKsuShim();
            }
        });

        // ── Native bridge ─────────────────────────────────────────────────────
        webView.addJavascriptInterface(new RootBridge(), "NativeBridge");

        // ── Load WebUI ────────────────────────────────────────────────────────
        webView.loadUrl("file:///android_asset/index.html");
    }

    /**
     * Inject a JavaScript shim that replaces the KSU ksu object with our
     * NativeBridge so the existing WebUI code works without modification.
     *
     * The shim handles both the Promise-style and callback-style ksu.exec().
     */
    private void injectKsuShim() {
        String shim =
            "(function() {" +
            "  var _cbMap = {};" +
            "  var _cbId  = 0;" +
            // Expose callback receiver for NativeBridge to call
            "  window.nativeCb = function(id, exitCode, stdout, stderr) {" +
            "    var cb = _cbMap[id];" +
            "    if (cb) { cb(exitCode, stdout, stderr); delete _cbMap[id]; }" +
            "  };" +
            // Build ksu shim
            "  window.ksu = {" +
            "    exec: function(cmd, env, callback) {" +
            "      var id = ++_cbId;" +
            "      if (typeof env === 'function') {" +
            "        callback = env; env = '';" +
            "      }" +
            "      if (typeof callback === 'function') {" +
            "        _cbMap[id] = callback;" +
            "        NativeBridge.exec(cmd, id);" +
            "        return;" +
            "      }" +
            // Promise-style (return value used directly)
            "      return new Promise(function(resolve, reject) {" +
            "        _cbMap[id] = function(e, o, err) {" +
            "          if (e === 0) resolve(o); else reject(err || o);" +
            "        };" +
            "        NativeBridge.exec(cmd, id);" +
            "      });" +
            "    }" +
            "  };" +
            // Signal that ksu is available
            "  console.log('[MalachiteOpt] KSU shim injected');" +
            "})();";

        webView.evaluateJavascript(shim, null);
    }

    // ── JavaScript Interface ──────────────────────────────────────────────────

    private class RootBridge {

        /**
         * Execute a shell command as root and call back into JS.
         * @param cmd        Shell command string
         * @param callbackId Opaque ID returned to nativeCb()
         */
        @JavascriptInterface
        public void exec(final String cmd, final int callbackId) {
            executor.execute(() -> {
                int exitCode = 1;
                StringBuilder stdout = new StringBuilder();
                StringBuilder stderr = new StringBuilder();

                try {
                    // Launch root shell
                    Process process = Runtime.getRuntime().exec("su");
                    DataOutputStream os = new DataOutputStream(process.getOutputStream());
                    BufferedReader outReader = new BufferedReader(
                            new InputStreamReader(process.getInputStream()));
                    BufferedReader errReader = new BufferedReader(
                            new InputStreamReader(process.getErrorStream()));

                    // Write command + exit
                    os.writeBytes(cmd + "\n");
                    os.writeBytes("exit\n");
                    os.flush();
                    os.close();

                    // Read stdout
                    String line;
                    while ((line = outReader.readLine()) != null) {
                        stdout.append(line).append("\n");
                    }
                    // Read stderr
                    while ((line = errReader.readLine()) != null) {
                        stderr.append(line).append("\n");
                    }

                    exitCode = process.waitFor();
                    process.destroy();

                } catch (Exception e) {
                    stderr.append("exec error: ").append(e.getMessage());
                }

                // Escape for JS string injection
                final int finalExit = exitCode;
                final String finalOut = escapeJs(stdout.toString());
                final String finalErr = escapeJs(stderr.toString());

                // Callback on main thread → JS
                mainHandler.post(() ->
                    webView.evaluateJavascript(
                        "window.nativeCb(" + callbackId + ", " + finalExit +
                        ", '" + finalOut + "', '" + finalErr + "');",
                        null)
                );
            });
        }

        /**
         * Show a Toast from JS (optional helper).
         */
        @JavascriptInterface
        public void toast(final String msg) {
            mainHandler.post(() ->
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show()
            );
        }

        /**
         * Check if SU binary is accessible (fast check, no shell spawn).
         */
        @JavascriptInterface
        public boolean hasSu() {
            String[] paths = {"/sbin/su", "/system/bin/su", "/system/xbin/su",
                              "/data/adb/magisk/su", "/data/adb/ksu/bin/su"};
            for (String p : paths) {
                if (new java.io.File(p).exists()) return true;
            }
            return false;
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static String escapeJs(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("'", "\\'")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        webView.destroy();
        super.onDestroy();
    }
}
