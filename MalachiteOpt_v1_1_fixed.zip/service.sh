#!/system/bin/sh
# MalachiteOpt v1.1 — service.sh
# Device  : Poco X7 / Redmi Note 14 Pro 5G (malachite / garnet)
# SoC     : MediaTek Dimensity 7300-Ultra (mt6878)
# CPU     : 4×A55 (cpu0-3) + 4×A78 (cpu4-7)
# GPU     : Mali-G615 MC4
# v1.1: MTK tweaks — DisableTrace, WALT, SFL phase offset, thermal kill, killlogd

# ── Wait for full boot (120s timeout — prevents infinite hang) ────────────────
_BOOT_ELAPSED=0
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 5
    _BOOT_ELAPSED=$(( _BOOT_ELAPSED + 5 ))
    if [ "$_BOOT_ELAPSED" -ge 120 ]; then
        echo "[WARN] boot_completed timeout after ${_BOOT_ELAPSED}s — proceeding"
        break
    fi
done
sleep 20

# ── Root manager detection ─────────────────────────────────────────────────────
_detect_root_manager() {
    if [ -f /data/adb/gopt_root_manager ] && [ -f /data/adb/gopt_module_base ]; then
        ROOT_MANAGER=$(cat /data/adb/gopt_root_manager 2>/dev/null)
        MODULE_BASE=$(cat /data/adb/gopt_module_base 2>/dev/null)
    fi
    case "$ROOT_MANAGER" in
        magisk|ksu|ksu_next|apatch) ;;
        *)
            if [ -d "/data/adb/magisk" ] && [ -f "/data/adb/magisk/magisk" ]; then
                ROOT_MANAGER="magisk"; MODULE_BASE="/data/adb/modules"
            elif [ -d "/data/adb/ksud" ] || [ "$(getprop ro.kernelsu.version 2>/dev/null)" != "" ]; then
                if [ -f "/data/adb/ksu/next" ] || [ "$(getprop ro.kernelsu.next 2>/dev/null)" != "" ]; then
                    ROOT_MANAGER="ksu_next"
                else
                    ROOT_MANAGER="ksu"
                fi
                MODULE_BASE="/data/adb/ksu/modules"
            elif [ -d "/data/adb/ap" ] || [ -f "/data/adb/apd" ]; then
                ROOT_MANAGER="apatch"; MODULE_BASE="/data/adb/ap/modules"
            else
                ROOT_MANAGER="unknown"; MODULE_BASE="/data/adb/modules"
            fi
            ;;
    esac
}
_detect_root_manager

# ── Paths ─────────────────────────────────────────────────────────────────────
MODDIR="${MODULE_BASE}/gaming_optimizer_pocox7"
CONFIG=/data/adb/gopt_config
GAMELIST=/data/adb/gopt_gamelist
LOG=${MODDIR}/optimizer.log

mkdir -p "$MODDIR"

# ── Log rotation: keep under 512KB ────────────────────────────────────────────
if [ -f "$LOG" ]; then
    _LOGSIZE=$(wc -c < "$LOG" 2>/dev/null || echo 0)
    if [ "$_LOGSIZE" -gt 524288 ]; then
        _LOGLINES=$(wc -l < "$LOG" 2>/dev/null || echo 0)
        _KEEP=$(( _LOGLINES / 2 ))
        tail -n "$_KEEP" "$LOG" > "${LOG}.tmp" 2>/dev/null && mv "${LOG}.tmp" "$LOG" 2>/dev/null
    fi
fi

: > "$LOG"
exec >> "$LOG" 2>&1

echo "=== MalachiteOpt v1.1 ==="
echo "Date      : $(date)"
echo "Device    : $(getprop ro.product.device) / $(getprop ro.product.model)"
echo "SoC       : Dimensity 7300-Ultra (mt6878)"
echo "Android   : $(getprop ro.build.version.release)"
echo "ROM       : $(getprop ro.build.flavor)"
echo "Root      : ${ROOT_MANAGER:-unknown}"

# ── Load config ────────────────────────────────────────────────────────────────
mode="balanced"
render="default"
refresh="default"
thermal="enable"
underclock="off"
hamada="on"
dex2oat="on"
tcp="on"
dns="on"
disabletrace="off"
walttunes="off"
sfltuning="on"
killlogd="off"

if [ -f "$CONFIG" ]; then
    # Safe config loading: read line by line to avoid injection
    while IFS='=' read -r _k _v; do
        case "$_k" in
            mode)         mode="$_v" ;;
            render)       render="$_v" ;;
            refresh)      refresh="$_v" ;;
            thermal)      thermal="$_v" ;;
            underclock)   underclock="$_v" ;;
            hamada)       hamada="$_v" ;;
            dex2oat)      dex2oat="$_v" ;;
            tcp)          tcp="$_v" ;;
            dns)          dns="$_v" ;;
            disabletrace) disabletrace="$_v" ;;
            walttunes)    walttunes="$_v" ;;
            sfltuning)    sfltuning="$_v" ;;
            killlogd)     killlogd="$_v" ;;
        esac
    done < "$CONFIG"
fi

echo ""
echo "--- Config ---"
echo "mode=$mode  render=$render  refresh=$refresh"
echo "thermal=$thermal  underclock=$underclock  hamada=$hamada"
echo "dex2oat=$dex2oat  tcp=$tcp  dns=$dns"
echo "disabletrace=$disabletrace  walttunes=$walttunes  sfltuning=$sfltuning  killlogd=$killlogd"

# ── Config whitelist validation ────────────────────────────────────────────────
case "$mode"         in balanced|performance|powersave|powersave_plus) ;; *) mode="balanced" ;; esac
case "$render"       in default|skiagl|vulkan|hybrid) ;; *) render="default" ;; esac
case "$refresh"      in default|60|90|120) ;; *) refresh="default" ;; esac
case "$thermal"      in enable|disable) ;; *) thermal="enable" ;; esac
case "$underclock"   in off|30|50|75) ;; *) underclock="off" ;; esac
case "$hamada"       in on|off) ;; *) hamada="on" ;; esac
case "$dex2oat"      in on|off) ;; *) dex2oat="on" ;; esac
case "$tcp"          in on|off) ;; *) tcp="on" ;; esac
case "$dns"          in on|off) ;; *) dns="on" ;; esac
case "$disabletrace" in on|off) ;; *) disabletrace="off" ;; esac
case "$walttunes"    in on|off) ;; *) walttunes="off" ;; esac
case "$sfltuning"    in on|off) ;; *) sfltuning="on" ;; esac
case "$killlogd"     in on|off) ;; *) killlogd="off" ;; esac

# ══════════════════════════════════════════════════════════════════════════════
# ── Helpers ───────────────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════

W() {
    local path="$1" val="$2"
    [ -e "$path" ] || return 0
    chmod 644 "$path" 2>/dev/null
    if echo "$val" > "$path" 2>/dev/null; then
        echo "[OK]   $path = $val"
    else
        echo "[FAIL] $path"
    fi
}

WL() {
    local path="$1" val="$2"
    [ -e "$path" ] || return 0
    chmod 644 "$path" 2>/dev/null
    if echo "$val" > "$path" 2>/dev/null; then
        chmod 444 "$path" 2>/dev/null
        echo "[OKL]  $path = $val"
    else
        echo "[FAIL] $path"
    fi
}

_find_resetprop() {
    if command -v resetprop > /dev/null 2>&1; then
        RESETPROP="resetprop"
    elif [ -f /data/adb/ksu/bin/resetprop ]; then
        RESETPROP="/data/adb/ksu/bin/resetprop"
    elif [ -f /data/adb/ap/bin/resetprop ]; then
        RESETPROP="/data/adb/ap/bin/resetprop"
    elif [ -f /data/adb/magisk/resetprop ]; then
        RESETPROP="/data/adb/magisk/resetprop"
    else
        RESETPROP="setprop"
    fi
    echo "[INFO] resetprop: $RESETPROP"
}

_which_maxfreq() { tr ' ' '\n' < "$1" | sort -nr | head -n 1; }
_which_minfreq() { tr ' ' '\n' < "$1" | grep -v '^[[:space:]]*$' | sort -n  | head -n 1; }
_which_midfreq() {
    local total mid
    total=$(wc -w < "$1")
    mid=$(( (total + 1) / 2 ))
    tr ' ' '\n' < "$1" | grep -v '^[[:space:]]*$' | sort -nr | head -n "$mid" | tail -n 1
}

devfreq_max_perf() {
    [ -f "$1/available_frequencies" ] || return 0
    local f; f=$(_which_maxfreq "$1/available_frequencies")
    WL "$1/max_freq" "$f"
    WL "$1/min_freq" "$f"
}
devfreq_unlock() {
    [ -f "$1/available_frequencies" ] || return 0
    local mx mn
    mx=$(_which_maxfreq "$1/available_frequencies")
    mn=$(_which_minfreq "$1/available_frequencies")
    W "$1/max_freq" "$mx"
    W "$1/min_freq" "$mn"
}
devfreq_min_perf() {
    [ -f "$1/available_frequencies" ] || return 0
    local f; f=$(_which_minfreq "$1/available_frequencies")
    WL "$1/max_freq" "$f"
    WL "$1/min_freq" "$f"
}

_mtk_gpufreq_min_index() { awk -F'[][]' '{print $2}' "$1" | tail  -n 1; }
_mtk_gpufreq_mid_index() {
    local total mid
    total=$(wc -l < "$1")
    mid=$(( (total + 1) / 2 ))
    awk -F'[][]' '{print $2}' "$1" | head -n "$mid" | tail -n 1
}

# ══════════════════════════════════════════════════════════════════════════════
# ── perfcommon — universal baseline tweaks ────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════
apply_perfcommon() {
    echo "--- perfcommon: universal baseline tweaks ---"

    W /proc/sys/kernel/panic              0
    W /proc/sys/kernel/panic_on_oops      0
    W /proc/sys/kernel/panic_on_warn      0
    W /proc/sys/kernel/softlockup_panic   0

    sync

    (
        for dir in /sys/block/*; do
            W "$dir/queue/iostats"    0
            W "$dir/queue/add_random" 0
        done
    ) &

    local avail_cc
    avail_cc=$(cat /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null)
    for algo in bbr3 bbr2 bbrplus bbr westwood cubic; do
        if echo "$avail_cc" | grep -qw "$algo"; then
            W /proc/sys/net/ipv4/tcp_congestion_control "$algo"
            echo "$algo" | grep -q "bbr" && BBR_AVAIL=1 || BBR_AVAIL=0
            break
        fi
    done
    W /proc/sys/net/ipv4/tcp_ecn      1
    W /proc/sys/net/ipv4/tcp_fastopen 3
    W /proc/sys/net/ipv4/tcp_sack     1
    W /proc/sys/net/ipv4/tcp_timestamps 1

    W /proc/sys/kernel/perf_cpu_time_max_percent  3
    W /proc/sys/kernel/sched_schedstats           0
    W /proc/sys/kernel/task_cpustats_enable       0
    W /proc/sys/kernel/sched_autogroup_enabled    0
    W /proc/sys/kernel/sched_child_runs_first     1
    W /proc/sys/kernel/sched_nr_migrate           32
    W /proc/sys/kernel/sched_migration_cost_ns    50000
    W /proc/sys/kernel/sched_min_granularity_ns   1000000
    W /proc/sys/kernel/sched_wakeup_granularity_ns 1500000

    if [ -f /sys/kernel/debug/sched_features ]; then
        W /sys/kernel/debug/sched_features "NEXT_BUDDY"
    fi

    W /proc/sys/kernel/sched_lib_name \
        "libunity.so, libil2cpp.so, libmain.so, libUE4.so, libgodot_android.so, libgdx.so, libgdx-box2d.so, libminecraftpe.so, libLive2DCubismCore.so, libyuzu-android.so, libryujinx.so, libcitra-android.so, libhdr_pro_engine.so, libandroidx.graphics.path.so, libeffect.so"
    W /proc/sys/kernel/sched_lib_mask_force  255

    W /proc/sys/vm/page-cluster              0
    W /proc/sys/vm/stat_interval             15
    W /proc/sys/vm/compaction_proactiveness  0

    W /sys/module/mmc_core/parameters/use_spi_crc  0
    W /sys/module/opchain/parameters/chain_on       0
    W /sys/module/cpufreq_bouncing/parameters/enable 0
    W /proc/task_info/task_sched_info/task_sched_info_enable 0
    W /proc/oplus_scheduler/sched_assist/sched_assist_enabled 0

    local tz
    for tz in /sys/class/thermal/thermal_zone*/policy; do
        W "$tz" "step_wise"
    done

    echo "--- perfcommon: done ---"
}

# ══════════════════════════════════════════════════════════════════════════════
# ── SurfaceFlinger Phase Offset Tuning ───────────────────────────────────────
# Dynamically calculate SF phase offsets based on actual refresh rate
# Dynamically calculates SF phase offsets based on actual refresh rate
# ══════════════════════════════════════════════════════════════════════════════
apply_sfl_tuning() {
    [ "$sfltuning" != "on" ] && return 0
    echo "--- SurfaceFlinger phase offset tuning ---"

    # Detect actual refresh rate
    local refresh_rate=60
    for _node in \
        /sys/devices/platform/mediatek/mtk_disp_drv/mtk_ddic_dsi0/panel_fps \
        /sys/devices/platform/mtk_disp_drv/mtk_ddic_dsi0/panel_fps \
        /sys/class/drm/card0/card0-DSI-1/panel_fps; do
        [ -r "$_node" ] && { refresh_rate=$(cat "$_node" 2>/dev/null); break; }
    done
    # Validate refresh_rate is a positive integer >= 30, else default to 60
    case "$refresh_rate" in
        ''|*[!0-9]*) refresh_rate=60 ;;
        *) [ "$refresh_rate" -lt 30 ] && refresh_rate=60 ;;
    esac

    local frame_duration_ns=$(( 1000000000 / refresh_rate ))
    echo "[SFL] refresh_rate=${refresh_rate}Hz, frame_duration=${frame_duration_ns}ns"

    # Phase ratios based on refresh rate (scaled by 1000 for integer arithmetic)
    # Format: app_phase_r sf_phase_r app_dur_r sf_dur_r (all x1000)
    local app_phase_r sf_phase_r app_dur_r sf_dur_r
    if [ "$refresh_rate" -ge 120 ]; then
        app_phase_r=680; sf_phase_r=850; app_dur_r=580; sf_dur_r=320
    elif [ "$refresh_rate" -ge 90 ]; then
        app_phase_r=660; sf_phase_r=820; app_dur_r=600; sf_dur_r=300
    elif [ "$refresh_rate" -ge 75 ]; then
        app_phase_r=640; sf_phase_r=800; app_dur_r=620; sf_dur_r=280
    else
        app_phase_r=620; sf_phase_r=750; app_dur_r=650; sf_dur_r=250
    fi

    # Integer multiply then divide by 1000 (no floating-point needed)
    local app_phase_offset_ns sf_phase_offset_ns app_duration sf_duration
    app_phase_offset_ns=$(( -(frame_duration_ns * app_phase_r / 1000) ))
    sf_phase_offset_ns=$(( -(frame_duration_ns * sf_phase_r  / 1000) ))
    app_duration=$(( frame_duration_ns * app_dur_r / 1000 ))
    sf_duration=$(( frame_duration_ns * sf_dur_r  / 1000 ))

    $RESETPROP -n debug.sf.early.app.duration            "$app_duration"
    $RESETPROP -n debug.sf.earlyGl.app.duration          "$app_duration"
    $RESETPROP -n debug.sf.late.app.duration             "$app_duration"
    $RESETPROP -n debug.sf.early.sf.duration             "$sf_duration"
    $RESETPROP -n debug.sf.earlyGl.sf.duration           "$sf_duration"
    $RESETPROP -n debug.sf.late.sf.duration              "$sf_duration"
    $RESETPROP -n debug.sf.early_app_phase_offset_ns     "$app_phase_offset_ns"
    $RESETPROP -n debug.sf.high_fps_early_app_phase_offset_ns "$app_phase_offset_ns"
    $RESETPROP -n debug.sf.high_fps_late_app_phase_offset_ns  "$app_phase_offset_ns"
    $RESETPROP -n debug.sf.early_phase_offset_ns         "$sf_phase_offset_ns"
    $RESETPROP -n debug.sf.high_fps_early_phase_offset_ns "$sf_phase_offset_ns"
    $RESETPROP -n debug.sf.high_fps_late_sf_phase_offset_ns "$sf_phase_offset_ns"
    $RESETPROP -n debug.sf.enable_advanced_sf_phase_offset 1
    $RESETPROP -n debug.sf.predict_hwc_composition_strategy 1
    $RESETPROP -n debug.sf.use_phase_offsets_as_durations 1
    $RESETPROP -n debug.sf.disable_hwc_vds 1
    # Disable debug/dump overhead
    $RESETPROP -n debug.sf.dump.enable 0
    $RESETPROP -n debug.sf.dump.external 0
    $RESETPROP -n debug.sf.dump.primary 0
    $RESETPROP -n debug.sf.luma_sampling 0
    $RESETPROP -n debug.sf.showupdates 0
    $RESETPROP -n debug.sf.treble_testing_override false
    $RESETPROP -n debug.sf.enable_transaction_tracing false
    # HWUI debug off
    $RESETPROP -n debug.hwui.filter_test_overhead false
    $RESETPROP -n debug.hwui.show_layers_updates false
    $RESETPROP -n debug.hwui.capture_skp_enabled false
    $RESETPROP -n debug.hwui.trace_gpu_resources false
    $RESETPROP -n debug.hwui.skia_tracing_enabled false
    $RESETPROP -n debug.hwui.nv_profiling false
    $RESETPROP -n debug.hwui.show_dirty_regions false
    $RESETPROP -n debug.hwui.profile false
    $RESETPROP -n debug.hwui.skip_empty_damage true
    $RESETPROP -n debug.hwui.use_gpu_pixel_buffers true
    $RESETPROP -n debug.hwui.use_partial_updates true
    echo "[SFL] app_phase=${app_phase_offset_ns}ns, sf_phase=${sf_phase_offset_ns}ns"
    echo "--- SFL tuning: done ---"
}

# ══════════════════════════════════════════════════════════════════════════════
# ── Disable Trace ────────────────────────────────────────────────────────────
# Clears kernel trace buffers and stops tracing subsystems (reduces overhead)
# ══════════════════════════════════════════════════════════════════════════════
apply_disable_trace() {
    [ "$disabletrace" != "on" ] && return 0
    echo "--- Disable trace ---"
    for trace_file in \
        /sys/kernel/tracing/instances/mmstat/trace \
        /sys/kernel/tracing/trace \
        $(find /sys/kernel/tracing/per_cpu/ -name trace 2>/dev/null); do
        [ -w "$trace_file" ] && echo "" > "$trace_file" 2>/dev/null && \
            echo "[OK]   cleared: $trace_file"
    done
    W /sys/kernel/tracing/options/overwrite    0
    W /sys/kernel/tracing/options/record-tgids 0
    # Stop Android tracing services
    cmd accessibility stop-trace    2>/dev/null || true
    cmd input_method tracing stop   2>/dev/null || true
    cmd window tracing stop         2>/dev/null || true
    cmd window tracing size 0       2>/dev/null || true
    echo "--- Disable trace: done ---"
}

# ══════════════════════════════════════════════════════════════════════════════
# ── WALT Scheduler Tuning ──────────────────────────────────────────────────
# Window-Assisted Load Tracking — improves task wake-up latency
# ══════════════════════════════════════════════════════════════════════════════
apply_walt_tuning() {
    [ "$walttunes" != "on" ] && return 0
    echo "--- WALT scheduler tuning ---"
    # WALT parameters (Qualcomm WALT / MTK variant)
    W /sys/kernel/debug/sched/walt_ravg_window    20000000
    W /sys/kernel/debug/sched/walt_scale_demand_divisor 20
    W /proc/sys/kernel/sched_use_walt_cpu_util    1
    W /proc/sys/kernel/sched_use_walt_task_util   1
    W /proc/sys/kernel/sched_walt_cpu_high_irqload_threshold 10
    # Reduce latency for top-app tasks
    W /proc/sys/kernel/sched_min_task_util_for_boost 40
    W /proc/sys/kernel/sched_min_task_util_for_colocation 35
    echo "--- WALT tuning: done ---"
}

# ══════════════════════════════════════════════════════════════════════════════
# ── Kill Logd ─────────────────────────────────────────────────────────────
# Stops logging daemons to reduce CPU/memory overhead
# ══════════════════════════════════════════════════════════════════════════════
apply_kill_logd() {
    local list_logger="logd traced statsd tcpdump cnss_diag subsystem_ramdump charge_logger wlan_logging"
    if [ "$killlogd" = "on" ]; then
        echo "--- Kill logd: stopping logging daemons ---"
        for logger in $list_logger; do
            stop "$logger" 2>/dev/null && echo "[OK]   stopped: $logger" || true
        done
    else
        echo "--- Kill logd: disabled (loggers running normally) ---"
    fi
}

# ══════════════════════════════════════════════════════════════════════════════
# ── MTK-specific helpers ──────────────────────────────────════════════════────
# ══════════════════════════════════════════════════════════════════════════════

_mtk_ppm_perf() {
    [ -d /proc/ppm ] || return 0
    grep -E "PWR_THRO|THERMAL|FORCE_LIMIT" /proc/ppm/policy_status 2>/dev/null | while read -r row; do
        local idx; idx=$(echo "$row" | sed 's/^\[\([0-9]*\)\].*/\1/')
        W /proc/ppm/policy_status "${idx} 0"
    done
}

_mtk_ppm_unlock() {
    [ -d /proc/ppm ] || return 0
    grep -E "PWR_THRO|THERMAL|FORCE_LIMIT" /proc/ppm/policy_status 2>/dev/null | while read -r row; do
        local idx; idx=$(echo "$row" | sed 's/^\[\([0-9]*\)\].*/\1/')
        W /proc/ppm/policy_status "${idx} 1"
    done
}

_mtk_cpufreq_ppm_max() {
    local cluster=0
    for path in /sys/devices/system/cpu/cpufreq/policy*; do
        [ -f "$path/cpuinfo_max_freq" ] || continue
        local maxf; maxf=$(cat "$path/cpuinfo_max_freq")
        W /proc/ppm/policy/hard_userlimit_max_cpu_freq "${cluster} ${maxf}"
        W /proc/ppm/policy/hard_userlimit_min_cpu_freq "${cluster} ${maxf}"
        cluster=$(( cluster + 1 ))
    done
}

_mtk_cpufreq_ppm_unlock() {
    local cluster=0
    for path in /sys/devices/system/cpu/cpufreq/policy*; do
        [ -f "$path/cpuinfo_max_freq" ] || continue
        local maxf minf
        maxf=$(cat "$path/cpuinfo_max_freq")
        minf=$(cat "$path/cpuinfo_min_freq")
        W /proc/ppm/policy/hard_userlimit_max_cpu_freq "${cluster} ${maxf}"
        W /proc/ppm/policy/hard_userlimit_min_cpu_freq "${cluster} ${minf}"
        cluster=$(( cluster + 1 ))
    done
}

_mtk_gpu_perf() {
    if [ -d /proc/gpufreqv2 ]; then
        WL /proc/gpufreqv2/fix_target_opp_index 0
    elif [ -f /proc/gpufreq/gpufreq_opp_dump ]; then
        local maxf
        maxf=$(sed -n 's/.*freq = \([0-9]\{1,\}\).*/\1/p' /proc/gpufreq/gpufreq_opp_dump | head -n 1)
        WL /proc/gpufreq/gpufreq_opp_freq "$maxf"
    fi
    if [ -f /proc/gpufreq/gpufreq_power_limited ]; then
        for setting in ignore_batt_oc ignore_batt_percent ignore_low_batt \
                       ignore_thermal_protect ignore_pbm_limited; do
            W /proc/gpufreq/gpufreq_power_limited "${setting} 1"
        done
    fi
    W /proc/mtk_batoc_throttling/battery_oc_protect_stop "stop 1"
    W /sys/kernel/eara_thermal/enable 0
}

_mtk_gpu_unlock() {
    W /proc/gpufreq/gpufreq_opp_freq 0
    W /proc/gpufreqv2/fix_target_opp_index -1
    local midx
    if [ -d /proc/gpufreqv2 ]; then
        midx=$(_mtk_gpufreq_min_index /proc/gpufreqv2/gpu_working_opp_table 2>/dev/null)
    else
        midx=$(_mtk_gpufreq_min_index /proc/gpufreq/gpufreq_opp_dump 2>/dev/null)
    fi
    [ -n "$midx" ] && W /sys/kernel/ged/hal/custom_boost_gpu_freq "$midx"
    if [ -f /proc/gpufreq/gpufreq_power_limited ]; then
        for setting in ignore_batt_oc ignore_batt_percent ignore_low_batt \
                       ignore_thermal_protect ignore_pbm_limited; do
            W /proc/gpufreq/gpufreq_power_limited "${setting} 0"
        done
    fi
    W /proc/mtk_batoc_throttling/battery_oc_protect_stop "stop 0"
    W /sys/kernel/eara_thermal/enable 1
}

_mtk_ddr_perf() {
    WL /sys/devices/platform/10012000.dvfsrc/helio-dvfsrc/dvfsrc_req_ddr_opp  0
    WL /sys/kernel/helio-dvfsrc/dvfsrc_force_vcore_dvfs_opp                   0
    devfreq_max_perf /sys/class/devfreq/mtk-dvfsrc-devfreq
}

_mtk_ddr_unlock() {
    W /sys/devices/platform/10012000.dvfsrc/helio-dvfsrc/dvfsrc_req_ddr_opp  -1
    W /sys/kernel/helio-dvfsrc/dvfsrc_force_vcore_dvfs_opp                   -1
    devfreq_unlock /sys/class/devfreq/mtk-dvfsrc-devfreq
}

_mtk_fpsgo_off()  { W /sys/kernel/fpsgo/common/force_onoff 0; }
_mtk_fpsgo_free() { W /sys/kernel/fpsgo/common/force_onoff 2; }

# ══════════════════════════════════════════════════════════════════════════════
# ── CPU profiles ──────────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════
apply_cpu_profile() {
    local profile="$1"
    echo "--- CPU profile: $profile ---"
    local gov_l gov_b min_l min_b max_l max_b

    case "$profile" in
        performance)
            gov_l="performance"; gov_b="performance"
            min_l=1800000;       min_b=2400000
            max_l=2000000;       max_b=2600000
            ;;
        powersave)
            gov_l="schedutil"; gov_b="schedutil"
            min_l=400000;      min_b=400000
            max_l=1600000;     max_b=1800000
            ;;
        powersave_plus)
            gov_l="powersave"; gov_b="schedutil"
            min_l=400000;      min_b=400000
            max_l=1200000;     max_b=1400000
            ;;
        *)  # balanced
            gov_l="schedutil"; gov_b="schedutil"
            min_l=500000;      min_b=800000
            max_l=2000000;     max_b=2600000
            ;;
    esac

    chmod -f 644 /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor 2>/dev/null
    chmod -f 644 /sys/devices/system/cpu/cpufreq/policy*/scaling_governor 2>/dev/null

    for i in 0 1 2 3; do
        W /sys/devices/system/cpu/cpu${i}/cpufreq/scaling_governor "$gov_l"
        W /sys/devices/system/cpu/cpu${i}/cpufreq/scaling_min_freq "$min_l"
        W /sys/devices/system/cpu/cpu${i}/cpufreq/scaling_max_freq "$max_l"
    done
    for i in 4 5 6 7; do
        W /sys/devices/system/cpu/cpu${i}/cpufreq/scaling_governor "$gov_b"
        W /sys/devices/system/cpu/cpu${i}/cpufreq/scaling_min_freq "$min_b"
        W /sys/devices/system/cpu/cpu${i}/cpufreq/scaling_max_freq "$max_b"
    done

    if [ "$profile" = "performance" ]; then
        chmod -f 444 /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor 2>/dev/null
        chmod -f 444 /sys/devices/system/cpu/cpufreq/policy*/scaling_governor 2>/dev/null
    fi

    if [ "$gov_b" = "schedutil" ]; then
        for i in 4 5 6 7; do
            W /sys/devices/system/cpu/cpu${i}/cpufreq/schedutil/up_rate_limit_us   500
            W /sys/devices/system/cpu/cpu${i}/cpufreq/schedutil/down_rate_limit_us 2000
        done
    fi

    if [ -d /proc/ppm ]; then
        if [ "$profile" = "performance" ]; then
            _mtk_ppm_perf
            _mtk_cpufreq_ppm_max
        else
            _mtk_ppm_unlock
            _mtk_cpufreq_ppm_unlock
        fi
    fi

    case "$profile" in
        performance) W /proc/cpufreq/cpufreq_power_mode 3 ;;
        powersave*)  W /proc/cpufreq/cpufreq_power_mode 1 ;;
        *)           W /proc/cpufreq/cpufreq_power_mode 0 ;;
    esac

    case "$profile" in
        performance) W /proc/cpufreq/cpufreq_cci_mode 1 ;;
        *)           W /proc/cpufreq/cpufreq_cci_mode 0 ;;
    esac

    case "$profile" in
        performance) W /sys/devices/system/cpu/eas/enable 0 ;;
        *)           W /sys/devices/system/cpu/eas/enable 2 ;;
    esac

    case "$profile" in
        performance) W /proc/sys/kernel/split_lock_mitigate 0 ;;
        *)           W /proc/sys/kernel/split_lock_mitigate 1 ;;
    esac

    if [ -f /sys/kernel/debug/sched_features ]; then
        case "$profile" in
            performance)
                W /sys/kernel/debug/sched_features "NEXT_BUDDY"
                W /sys/kernel/debug/sched_features "NO_TTWU_QUEUE"
                ;;
            *)
                W /sys/kernel/debug/sched_features "NEXT_BUDDY"
                W /sys/kernel/debug/sched_features "TTWU_QUEUE"
                ;;
        esac
    fi

    if [ -d /dev/stune ]; then
        case "$profile" in
            performance)
                W /dev/stune/top-app/schedtune.prefer_idle 1
                W /dev/stune/top-app/schedtune.boost       1
                ;;
            *)
                W /dev/stune/top-app/schedtune.prefer_idle 0
                W /dev/stune/top-app/schedtune.boost       1
                ;;
        esac
    fi

    if [ -f /sys/module/battery_saver/parameters/enabled ]; then
        if grep -qo '[0-9]\+' /sys/module/battery_saver/parameters/enabled 2>/dev/null; then
            case "$profile" in
                powersave*) W /sys/module/battery_saver/parameters/enabled 1 ;;
                *)          W /sys/module/battery_saver/parameters/enabled 0 ;;
            esac
        else
            case "$profile" in
                powersave*) W /sys/module/battery_saver/parameters/enabled Y ;;
                *)          W /sys/module/battery_saver/parameters/enabled N ;;
            esac
        fi
    fi

    if [ -d /proc/touchpanel ]; then
        case "$profile" in
            performance)
                W /proc/touchpanel/game_switch_enable    1
                W /proc/touchpanel/oplus_tp_limit_enable 0
                W /proc/touchpanel/oppo_tp_limit_enable  0
                W /proc/touchpanel/oplus_tp_direction    1
                W /proc/touchpanel/oppo_tp_direction     1
                ;;
            *)
                W /proc/touchpanel/game_switch_enable    0
                W /proc/touchpanel/oplus_tp_limit_enable 1
                W /proc/touchpanel/oppo_tp_limit_enable  1
                W /proc/touchpanel/oplus_tp_direction    0
                W /proc/touchpanel/oppo_tp_direction     0
                ;;
        esac
    fi
}

apply_underclock() {
    local pct="$1"
    [ "$pct" = "off" ] && return 0
    echo "--- Underclock: ${pct}% ---"
    local cap_l cap_b base_l base_b
    base_l=$(cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 2000000)
    base_b=$(cat /sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq 2>/dev/null || echo 2600000)
    cap_l=$(( base_l * pct / 100 ))
    cap_b=$(( base_b * pct / 100 ))
    chmod -f 644 /sys/devices/system/cpu/cpu*/cpufreq/scaling_max_freq 2>/dev/null
    for i in 0 1 2 3; do W /sys/devices/system/cpu/cpu${i}/cpufreq/scaling_max_freq "$cap_l"; done
    for i in 4 5 6 7; do W /sys/devices/system/cpu/cpu${i}/cpufreq/scaling_max_freq "$cap_b"; done
}

# ══════════════════════════════════════════════════════════════════════════════
# ── GPU profile ───────────────────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════
apply_gpu_profile() {
    local profile="$1"
    echo "--- GPU profile: $profile ---"
    local MALI="" DEVFREQ="" p

    for p in \
        /sys/devices/platform/13000000.mali \
        /sys/devices/platform/soc/13000000.mali \
        /sys/devices/platform/mali.0 \
        /sys/class/misc/mali0; do
        [ -d "$p" ] && { MALI="$p"; break; }
    done
    for p in \
        /sys/class/devfreq/13000000.mali \
        /sys/class/devfreq/soc:mali \
        /sys/class/devfreq/mali; do
        [ -d "$p" ] && { DEVFREQ="$p"; break; }
    done

    local gpu_gov ged_boost ged_idle ged_smart
    case "$profile" in
        performance)
            gpu_gov="performance"
            ged_boost=100; ged_idle=50;  ged_smart=1
            ;;
        powersave|powersave_plus)
            gpu_gov="simple_ondemand"
            ged_boost=0;   ged_idle=500; ged_smart=0
            ;;
        *)  # balanced
            gpu_gov="simple_ondemand"
            ged_boost=50;  ged_idle=200; ged_smart=1
            ;;
    esac

    if [ -n "$DEVFREQ" ]; then
        W "${DEVFREQ}/governor" "$gpu_gov"
        if [ "$profile" = "performance" ]; then
            devfreq_max_perf "$DEVFREQ"
        elif [ "$profile" = "powersave" ] || [ "$profile" = "powersave_plus" ]; then
            devfreq_min_perf "$DEVFREQ"
        else
            devfreq_unlock "$DEVFREQ"
        fi
    fi

    case "$profile" in
        performance)
            _mtk_gpu_perf
            W /sys/module/sspm_v3/holders/ged/parameters/is_GED_KPI_enabled 0
            ;;
        *)
            _mtk_gpu_unlock
            W /sys/module/sspm_v3/holders/ged/parameters/is_GED_KPI_enabled 1
            ;;
    esac

    [ -n "$MALI" ] && W "${MALI}/shader_present" 15
    W /sys/module/ged/parameters/gpu_dvfs_enable     1
    W /sys/module/ged/parameters/boost_gpu_enable    1
    W /sys/module/ged/parameters/ged_smart_boost     "$ged_smart"
    W /sys/module/ged/parameters/gpu_boost_level     "$ged_boost"
    W /sys/module/ged/parameters/gpu_idle_timeout_ms "$ged_idle"

    case "$profile" in
        performance) _mtk_fpsgo_off  ;;
        *)           _mtk_fpsgo_free ;;
    esac

    case "$profile" in
        performance)
            WL /sys/devices/platform/boot_dramboost/dramboost/dramboost 1
            _mtk_ddr_perf
            ;;
        *)
            W /sys/devices/platform/boot_dramboost/dramboost/dramboost 0
            _mtk_ddr_unlock
            ;;
    esac

    (
        for path in /sys/class/devfreq/*.ufshc /sys/class/devfreq/mmc*; do
            case "$profile" in
                performance)    devfreq_max_perf "$path" ;;
                powersave*)     devfreq_min_perf "$path" ;;
                *)              devfreq_unlock   "$path" ;;
            esac
        done
    ) &

    [ "$profile" = "performance" ] && echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
}

apply_render() {
    local r="$1"
    [ "$r" = "default" ] && return 0
    echo "--- Render: $r ---"
    case "$r" in
        skiagl)
            setprop debug.hwui.renderer        "skiagl" 2>/dev/null
            setprop persist.sys.ui.hw          "true"   2>/dev/null ;;
        vulkan)
            setprop debug.hwui.renderer        "skiavk" 2>/dev/null
            setprop debug.vulkan.layers        ""       2>/dev/null ;;
        hybrid)
            setprop debug.hwui.renderer        "skiagl" 2>/dev/null
            setprop debug.renderengine.backend "skiaVk" 2>/dev/null ;;
    esac
}

_do_apply_refresh() {
    local hz="$1"
    local hzf="${hz}.0"

    local _att=1
    while [ "$_att" -le 5 ]; do
        settings put system peak_refresh_rate "$hzf" 2>/dev/null && break
        _att=$(( _att + 1 )); sleep 1
    done
    settings put system min_refresh_rate  "$hzf" 2>/dev/null || true
    settings put system user_refresh_rate "$hz"  2>/dev/null || true

    $RESETPROP persist.vendor.display.miui.refresh_rate        "$hz"  2>/dev/null || true
    $RESETPROP persist.vendor.display_rate                     "$hz"  2>/dev/null || true
    $RESETPROP persist.sys.displays.display0.peak_refresh_rate "$hz"  2>/dev/null || true
    $RESETPROP persist.sys.displays.display0.min_refresh_rate  "$hz"  2>/dev/null || true
    $RESETPROP debug.sf.override_peak_refresh_rate             "$hz"  2>/dev/null || true

    if [ -n "$(getprop ro.hyperos.version 2>/dev/null)" ] || \
       [ -n "$(getprop ro.miui.ui.version.name 2>/dev/null)" ]; then
        stop display_feature 2>/dev/null || true
        sleep 1
        $RESETPROP persist.vendor.display.miui.refresh_rate "$hz" 2>/dev/null || true
        settings put system peak_refresh_rate "$hzf" 2>/dev/null || true
        settings put system min_refresh_rate  "$hzf" 2>/dev/null || true
        $RESETPROP persist.vendor.miaidt.refresh_rate "$hz" 2>/dev/null || true
        start display_feature 2>/dev/null || true
        sleep 1
        am broadcast -a com.miui.powercenter.UPDATE_REFRESH_RATE \
            --ei refresh_rate "$hz" 2>/dev/null || true
    fi

    for _node in \
        /sys/devices/platform/mediatek/mtk_disp_drv/mtk_ddic_dsi0/panel_fps \
        /sys/devices/platform/mtk_disp_drv/mtk_ddic_dsi0/panel_fps \
        /sys/class/drm/card0/card0-DSI-1/panel_fps; do
        if [ -w "$_node" ]; then
            local _a=1
            while [ "$_a" -le 5 ]; do
                echo "$hz" > "$_node" 2>/dev/null && break
                _a=$(( _a + 1 )); sleep 1
            done
            echo "[OK]   $_node = $hz"
            break
        fi
    done
}

apply_refresh() {
    local hz="$1"
    [ "$hz" = "default" ] && return 0
    echo "--- Refresh: ${hz}Hz ---"
    _do_apply_refresh "$hz"
}

_start_refresh_daemon() {
    local hz="$1"
    [ "$hz" = "default" ] && return 0
    echo "--- Refresh daemon started (${hz}Hz) ---"
    (
        _LAST_WAKEUP="-1"
        while true; do
            sleep 3
            _CW=""
            [ -r /sys/kernel/power/wakeup_count ] && \
                _CW=$(cat /sys/kernel/power/wakeup_count 2>/dev/null)
            [ -n "$_CW" ] && [ "$_CW" != "$_LAST_WAKEUP" ] && {
                _LAST_WAKEUP="$_CW"
                _do_apply_refresh "$hz" >> "$LOG" 2>&1
            }
        done
    ) &
    echo "Refresh daemon PID: $!"
}

apply_cpuset() {
    echo "--- cpuset ---"
    W /dev/cpuset/top-app/cpus            "4-7"
    W /dev/cpuset/foreground/cpus         "0-7"
    W /dev/cpuset/background/cpus         "0-3"
    W /dev/cpuset/system-background/cpus  "0-2"
    W /dev/cpuset/restricted/cpus         "0-3"
}

apply_io() {
    echo "--- I/O ---"
    local dev
    for dev in /sys/block/sda /sys/block/sdb /sys/block/sdc; do
        W "${dev}/queue/scheduler"      "mq-deadline"
        W "${dev}/queue/nr_requests"    "128"
        W "${dev}/queue/read_ahead_kb"  "128"
        W "${dev}/queue/add_random"     "0"
        W "${dev}/queue/iostats"        "0"
    done
    for ufs in /sys/bus/platform/drivers/ufshcd/*/; do
        [ -d "$ufs" ] && W "${ufs}power/autosuspend_delay_ms" "0"
    done
}

apply_vm() {
    echo "--- VM ---"
    W /proc/sys/vm/swappiness                60
    W /proc/sys/vm/dirty_ratio               10
    W /proc/sys/vm/dirty_background_ratio    5
    W /proc/sys/vm/page-cluster              0
    W /proc/sys/vm/vfs_cache_pressure        80
}

apply_thermal() {
    echo "--- Thermal: $thermal ---"
    if [ "$thermal" = "disable" ]; then
        # Aggressively stop thermal services and processes
        stop thermal-engine        2>/dev/null || true
        stop mi_thermald           2>/dev/null || true
        stop vendor.thermal-engine 2>/dev/null || true

        # Kill remaining thermal processes
        pkill -f thermald 2>/dev/null || true
        ps -A 2>/dev/null | grep -iE 'thermal-engine|thermald|mtk_thermal' \
            | awk '{print $2}' | while read -r pid; do
            kill -9 "$pid" 2>/dev/null
        done

        # Disable thermal zones
        local tz
        for tz in /sys/class/thermal/thermal_zone*/mode; do W "$tz" "disabled"; done
        for tz in /sys/class/thermal/thermal_zone*/policy; do W "$tz" "userspace"; done

        # Disable PPM thermal limits
        [ -f /proc/ppm/policy_status ] && \
            grep -E 'FORCE_LIMIT|PWR_THRO|THERMAL' /proc/ppm/policy_status 2>/dev/null \
            | awk -F'[][]' '{print $2}' | while read -r idx; do
                W /proc/ppm/policy_status "${idx} 0"
            done

        # Disable GPU thermal
        if [ -f /proc/gpufreq/gpufreq_power_limited ]; then
            for k in ignore_batt_oc ignore_batt_percent ignore_low_batt \
                     ignore_thermal_protect ignore_pbm_limited; do
                W /proc/gpufreq/gpufreq_power_limited "${k} 1"
            done
        fi

        # Battery OC
        W /proc/mtk_batoc_throttling/battery_oc_protect_stop "stop 1"
        cmd thermalservice override-status 0 2>/dev/null || true
    else
        local tz
        for tz in /sys/class/thermal/thermal_zone*/mode; do W "$tz" "enabled"; done
        start thermal-engine        2>/dev/null || true
        start mi_thermald           2>/dev/null || true
        start vendor.thermal-engine 2>/dev/null || true
        W /proc/mtk_batoc_throttling/battery_oc_protect_stop "stop 0"
    fi
}

apply_vm_profile() {
    case "$1" in
        performance) W /proc/sys/vm/vfs_cache_pressure  80 ;;
        *)           W /proc/sys/vm/vfs_cache_pressure 120 ;;
    esac
}

apply_tcp() {
    if [ "$tcp" != "on" ]; then
        echo "--- TCP optimizer: disabled ---"
        return 0
    fi
    echo "--- TCP / Network optimizer ---"

    if [ -z "$BBR_AVAIL" ]; then
        local avail_cc
        avail_cc=$(cat /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null)
        echo "$avail_cc" | grep -qw "bbr" && BBR_AVAIL=1 || BBR_AVAIL=0
    fi

    TC_BIN=""
    for _tc in /system/bin/tc /vendor/bin/tc /system/xbin/tc; do
        [ -x "$_tc" ] && { TC_BIN="$_tc"; break; }
    done
    command -v tc > /dev/null 2>&1 && TC_BIN="tc"

    if [ -n "$TC_BIN" ]; then
        for iface in wlan0 wlan1 rmnet_data0 rmnet_data1 ccmni0; do
            if ip link show "$iface" > /dev/null 2>&1; then
                $TC_BIN qdisc replace dev "$iface" root fq 2>/dev/null \
                    && echo "[OK]   tc fq: $iface" \
                    || echo "[SKIP] tc fq: $iface"
            fi
        done
    else
        echo "[SKIP] tc not found — skipping qdisc"
    fi

    W /proc/sys/net/core/rmem_max           4194304
    W /proc/sys/net/core/wmem_max           4194304
    W /proc/sys/net/ipv4/tcp_rmem           "4096 262144 4194304"
    W /proc/sys/net/ipv4/tcp_wmem           "4096 262144 4194304"
    W /proc/sys/net/core/netdev_max_backlog  5000
    W /proc/sys/net/ipv4/tcp_slow_start_after_idle  0
    W /proc/sys/net/ipv4/tcp_syn_retries    2
    W /proc/sys/net/ipv4/tcp_synack_retries 2
    W /proc/sys/net/ipv4/tcp_fin_timeout    15
    W /proc/sys/net/ipv4/tcp_keepalive_time   60
    W /proc/sys/net/ipv4/tcp_keepalive_intvl  10
    W /proc/sys/net/ipv4/tcp_keepalive_probes  5
    W /proc/sys/net/ipv4/tcp_window_scaling    1
    W /proc/sys/net/ipv4/tcp_moderate_rcvbuf   1
    W /proc/sys/net/ipv4/tcp_mtu_probing       1
    W /proc/sys/net/ipv4/tcp_no_metrics_save   1

    for iface in wlan0 wlan1; do
        ip link show "$iface" > /dev/null 2>&1 && \
            ip link set "$iface" txqueuelen 1000 2>/dev/null && \
            echo "[OK]   txqueuelen 1000: $iface"
    done

    echo "--- TCP optimizer: done ---"
}

start_tcp_iface_watcher() {
    [ "$tcp" != "on" ] && return 0
    [ "$BBR_AVAIL" != "1" ] && return 0
    echo "--- TCP iface watcher started ---"
    (
        LAST_IFACE=""
        while true; do
            sleep 15
            CURR_IFACE=""
            ip link show wlan0  2>/dev/null | grep -q "state UP" && CURR_IFACE="wifi"
            [ -z "$CURR_IFACE" ] && \
                ip link show wlan1  2>/dev/null | grep -q "state UP" && CURR_IFACE="wifi"
            [ -z "$CURR_IFACE" ] && \
                ip link show rmnet_data0 2>/dev/null | grep -q "state UP" && CURR_IFACE="cell"
            [ -z "$CURR_IFACE" ] && \
                ip link show ccmni0 2>/dev/null | grep -q "state UP" && CURR_IFACE="cell"
            [ -z "$CURR_IFACE" ] && continue
            [ "$CURR_IFACE" = "$LAST_IFACE" ] && continue
            if [ "$CURR_IFACE" = "wifi" ]; then
                echo "bbr"   > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null \
                    && echo "[TCP-WATCH] WiFi -> BBR"
            else
                echo "cubic" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null \
                    && echo "[TCP-WATCH] Cellular -> CUBIC"
            fi
            LAST_IFACE="$CURR_IFACE"
        done
    ) &
    echo "TCP iface watcher PID: $!"
}

_ndc_set_dns() {
    local netid="$1"
    [ -z "$netid" ] && return 0
    ndc dnsresolver setresolverconfig "$netid" "" "1.1.1.1" "1.0.0.1" "" "" 2>/dev/null && \
        echo "[OK]   ndc dnsresolver netId=$netid" && return 0
    ndc resolver setnetdns "$netid" "" "1.1.1.1" "1.0.0.1" 2>/dev/null && \
        echo "[OK]   ndc resolver setnetdns netId=$netid" && return 0
    echo "[SKIP] ndc dns push failed for netId=$netid"
}

_get_active_netids() {
    dumpsys connectivity 2>/dev/null \
        | grep -E "^  (Network|NetworkAgentInfo).*{" \
        | grep -oE "netId=[0-9]+" \
        | cut -d= -f2
}

apply_dns() {
    if [ "$dns" != "on" ]; then
        echo "--- DNS: disabled ---"
        return 0
    fi
    echo "--- DNS accelerator ---"
    settings put global private_dns_mode      "hostname"        2>/dev/null \
        && echo "[OK]   Private DNS mode = hostname (DoT)"
    settings put global private_dns_specifier "one.one.one.one" 2>/dev/null \
        && echo "[OK]   Private DNS = one.one.one.one (Cloudflare DoT)"
    local _netid
    for _netid in $(_get_active_netids); do _ndc_set_dns "$_netid"; done
    for _netid in 100 101 102; do
        ndc resolver setnetdns "$_netid" "" "1.1.1.1" "1.0.0.1" 2>/dev/null || true
    done
    echo "--- DNS: done ---"
}

start_dns_watcher() {
    [ "$dns" != "on" ] && return 0
    echo "--- DNS watcher started ---"
    (
        _LAST_NET=""
        while true; do
            sleep 10
            _CURR_NET=$(ip route show default 2>/dev/null | head -1)
            [ "$_CURR_NET" = "$_LAST_NET" ] && continue
            [ -z "$_CURR_NET" ] && { _LAST_NET=""; continue; }
            _LAST_NET="$_CURR_NET"
            echo "[DNS-WATCH] Network change — re-pushing DNS"
            settings put global private_dns_mode      "hostname"        2>/dev/null
            settings put global private_dns_specifier "one.one.one.one" 2>/dev/null
            local _netid
            for _netid in $(_get_active_netids); do _ndc_set_dns "$_netid"; done
        done
    ) &
    echo "DNS watcher PID: $!"
}

seed_gamelist() {
    if [ -s "$GAMELIST" ]; then
        echo "--- Gamelist: $(wc -l < "$GAMELIST") games loaded ---"
        return 0
    fi
    echo "--- Gamelist: seeding ---"
    cat > "$GAMELIST" << 'GAMES'
com.mobilelegends.ml.bg.and.bad.guys
com.tencent.ig
com.pubg.krmobile
com.battlegrounds.mobile.india.bgmi
com.garena.game.freefire
com.garena.game.rov
com.tencent.tmgp.kr.codm
com.vng.codmvn
com.redfox.undawn
com.netease.newsfantasy
com.netease.onmyoji
com.netease.mrjk.asia
com.YoStarEN.Arknights
com.YoStarEN.AzurLane
com.YoStarEN.HBR
com.proximabeta.mf.u4
com.roblox.client
com.nexon.bluearchive
com.RoamingStar.BlueArchive
com.YostarJP.BlueArchive
com.zl.torchlight.infinity.en
com.bandainamcoent.dblegendsww
com.bandainamcoent.opbrww
com.ProjectMoon.LimbusCompany
com.bhvr.deadbydaylight
com.axlebolt.standoff2
com.autumn.skullgirls
com.bilibili.deadcells.mobile
com.Psyonix.RL2D
com.dts.freefireth
com.and.games505.Terraria
com.and.games505.TerrariaPaid
GAMES
    echo "--- Gamelist: seeded $(wc -l < "$GAMELIST") games ---"
}

apply_dex2oat() {
    if [ "$dex2oat" != "on" ]; then
        echo "--- dex2oat: disabled ---"
        return 0
    fi
    echo ""
    echo "=== dex2oat ART Optimizer ==="
    echo "--- started: $(date) ---"
    sync

    $RESETPROP dalvik.vm.minidebuginfo                   false         2>/dev/null && echo "[OK] minidebuginfo=false"
    $RESETPROP dalvik.vm.dex2oat-minidebuginfo           false         2>/dev/null && echo "[OK] dex2oat-minidebuginfo=false"
    $RESETPROP dalvik.vm.check-dex-sum                   false         2>/dev/null && echo "[OK] check-dex-sum=false"
    $RESETPROP dalvik.vm.checkjni                        false         2>/dev/null && echo "[OK] checkjni=false"
    $RESETPROP dalvik.vm.verify-bytecode                 false         2>/dev/null && echo "[OK] verify-bytecode=false"
    $RESETPROP dalvik.gc.type                            generational_cc 2>/dev/null && echo "[OK] gc.type=generational_cc"
    $RESETPROP dalvik.vm.dex2oat-swap                    true          2>/dev/null && echo "[OK] dex2oat-swap=true"
    $RESETPROP dalvik.vm.dex2oat-resolve-startup-strings true          2>/dev/null && echo "[OK] resolve-startup-strings=true"
    $RESETPROP dalvik.vm.systemservercompilerfilter       speed-profile 2>/dev/null && echo "[OK] systemserver=speed-profile"
    $RESETPROP dalvik.vm.systemuicompilerfilter           speed-profile 2>/dev/null && echo "[OK] systemui=speed-profile"
    $RESETPROP dalvik.vm.usap_pool_enabled                true          2>/dev/null && echo "[OK] usap_pool=true"

    _DEX_FLAG="/data/adb/gopt_dex2oat_done"
    _CUR_VER=$(cat /data/adb/gopt_dex2oat_version 2>/dev/null || echo "0")
    _MOD_VER="10"  # v1.0 — bump when dex2oat logic changes to force re-run
    if [ ! -f "$_DEX_FLAG" ] || [ "$_CUR_VER" != "$_MOD_VER" ]; then
        echo "[INFO] Running pm compile (first boot after install/update)..."
        pm compile -m speed-profile -a                 2>/dev/null && echo "[OK] speed-profile -a"     || echo "[SKIP] speed-profile -a"
        pm compile -m speed-profile --secondary-dex -a 2>/dev/null && echo "[OK] secondary-dex"        || echo "[SKIP] secondary-dex"
        pm compile --compile-layouts -a                2>/dev/null && echo "[OK] compile-layouts"       || echo "[SKIP] compile-layouts"
        pm art dexopt-packages -r bg-dexopt            2>/dev/null && echo "[OK] art dexopt-packages"   || echo "[SKIP] art dexopt-packages"
        pm art cleanup                                 2>/dev/null && echo "[OK] art cleanup"            || echo "[SKIP] art cleanup"
        touch "$_DEX_FLAG"
        echo "$_MOD_VER" > /data/adb/gopt_dex2oat_version
        echo "[INFO] pm compile complete — flag set"
    else
        echo "[INFO] pm compile skipped — already ran on this install (delete $_DEX_FLAG to force re-run)"
    fi

    echo "--- dex2oat: done $(date) ---"
    echo "=== dex2oat Done ==="
}

# ══════════════════════════════════════════════════════════════════════════════
# ── Main: apply everything ─────────────────────────────────────────────────
# ══════════════════════════════════════════════════════════════════════════════
echo ""
echo "--- Applying: $mode ---"

# BUG FIX: _find_resetprop MUST run before apply_render/apply_refresh/apply_sfl_tuning
_find_resetprop

apply_perfcommon
apply_cpuset
apply_vm
apply_vm_profile "$mode"
apply_io
apply_cpu_profile  "$mode"
apply_underclock   "$underclock"
apply_gpu_profile  "$mode"
apply_render       "$render"
apply_refresh      "$refresh"
_start_refresh_daemon "$refresh"
apply_thermal
apply_tcp
start_tcp_iface_watcher
apply_dns
start_dns_watcher
seed_gamelist

# Advanced tweaks (run after main boot setup)
apply_sfl_tuning
apply_walt_tuning
apply_kill_logd
apply_disable_trace

echo ""
echo "--- Boot setup complete: $(date) ---"

# Post-boot refresh defense
if [ "$refresh" != "default" ]; then
    (
        sleep 15
        echo "[$(date)] Re-applying refresh rate (post-boot defense)..."
        _do_apply_refresh "$refresh"
    ) &
fi

# dex2oat: background
(
    sleep 10
    apply_dex2oat
) &
echo "dex2oat PID: $!"

# ── QuartzAI — Auto Game Boost ────────────────────────────────────────────────
if [ "$hamada" = "on" ] && [ -s "$GAMELIST" ]; then
    echo "--- QuartzAI watcher started ---"
    (
        LAST_BOOST="none"
        while true; do
            sleep 8
            FG=$(dumpsys activity activities 2>/dev/null \
                | grep "topResumedActivity" \
                | grep -o "cmp=[^ ]*" \
                | head -1 \
                | sed 's/cmp=//;s/\/.*//')
            [ -z "$FG" ] && continue

            if grep -qxF "$FG" "$GAMELIST" 2>/dev/null; then
                if [ "$LAST_BOOST" != "gaming" ]; then
                    echo "[QUARTZAI] Game: $FG — boosting"
                    apply_cpu_profile "performance"
                    apply_gpu_profile "performance"
                    apply_vm_profile  "performance"
                    GAME_PID=$(pidof "$FG" 2>/dev/null | head -1)
                    [ -n "$GAME_PID" ] && echo -700 > /proc/${GAME_PID}/oom_score_adj 2>/dev/null
                    LAST_BOOST="gaming"
                fi
            elif [ "$LAST_BOOST" = "gaming" ]; then
                echo "[QUARTZAI] Game exited — restoring $mode"
                apply_cpu_profile "$mode"
                apply_gpu_profile "$mode"
                apply_vm_profile "$mode"
                LAST_BOOST="none"
            fi
        done
    ) &
    echo "QuartzAI PID: $!"
fi

echo "=== MalachiteOpt v1.0 Done ==="
