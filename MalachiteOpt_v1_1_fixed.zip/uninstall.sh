#!/system/bin/sh
# MalachiteOpt v1.1 — uninstall.sh
# Reverses refresh rate settings. Performance tweaks (CPU/GPU/VM) are
# volatile (sysfs/procfs) and reset automatically on reboot.

# ── Locate module directory (root-manager-agnostic) ──────────────
MODID="gaming_optimizer_pocox7"
MODULE_BASE=""
if [ -f /data/adb/gopt_module_base ]; then
    MODULE_BASE=$(cat /data/adb/gopt_module_base 2>/dev/null)
fi
# Fallback: probe known locations
if [ -z "$MODULE_BASE" ] || [ ! -d "${MODULE_BASE}/${MODID}" ]; then
    for _base in /data/adb/modules /data/adb/ksu/modules /data/adb/ap/modules; do
        [ -d "${_base}/${MODID}" ] && { MODULE_BASE="$_base"; break; }
    done
fi
[ -z "$MODULE_BASE" ] && MODULE_BASE="/data/adb/modules"
LOG="${MODULE_BASE}/${MODID}/optimizer.log"

_ulog() { echo "[$(date '+%H:%M:%S')] [UNINSTALL] $*" >> "$LOG" 2>/dev/null; }
_ulog "=== Uninstall started ==="

# ── Locate resetprop ──────────────────────────────────────────
RESETPROP=""
if command -v resetprop > /dev/null 2>&1; then
    RESETPROP="resetprop"
elif [ -f /data/adb/ksud ] && /data/adb/ksud resetprop --help >/dev/null 2>&1; then
    RESETPROP="/data/adb/ksud resetprop"
elif [ -f /data/adb/ksu/bin/resetprop ]; then
    RESETPROP="/data/adb/ksu/bin/resetprop"
elif [ -f /data/adb/ap/bin/resetprop ]; then
    RESETPROP="/data/adb/ap/bin/resetprop"
elif [ -f /data/adb/magisk/resetprop ]; then
    RESETPROP="/data/adb/magisk/resetprop"
else
    RESETPROP="setprop"
fi

# ── Restore display settings to system default ───────────────
settings delete system peak_refresh_rate   2>/dev/null && _ulog "Cleared peak_refresh_rate"
settings delete system min_refresh_rate    2>/dev/null && _ulog "Cleared min_refresh_rate"
settings delete system user_refresh_rate   2>/dev/null && _ulog "Cleared user_refresh_rate"

$RESETPROP --delete persist.vendor.display.miui.refresh_rate        2>/dev/null || true
$RESETPROP --delete persist.vendor.display_rate                     2>/dev/null || true
$RESETPROP --delete persist.sys.displays.display0.peak_refresh_rate 2>/dev/null || true
$RESETPROP --delete persist.sys.displays.display0.min_refresh_rate  2>/dev/null || true
$RESETPROP --delete persist.vendor.miaidt.refresh_rate              2>/dev/null || true
$RESETPROP --delete debug.sf.override_peak_refresh_rate             2>/dev/null || true
_ulog "Cleared persist props"

# ── Restart display_feature on HyperOS ───────────────────────
stop  display_feature 2>/dev/null || true
sleep 1
start display_feature 2>/dev/null || true
_ulog "display_feature restarted"

# ── Remove cached root manager files ─────────────────────────
rm -f /data/adb/gopt_root_manager
rm -f /data/adb/gopt_module_base
rm -f /data/adb/gopt_dex2oat_done
rm -f /data/adb/gopt_dex2oat_version
_ulog "=== Uninstall complete ==="
