#!/system/bin/sh
SKIPUNZIP=1

ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
ui_print "  MalachiteOpt v1.1 by mujinn"
ui_print "  Poco X7 / Redmi Note 14 Pro 5G"
ui_print "  MTK Perf + Scheduler + Display tweaks"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── Device check ──────────────────────────────────────────────
DEVICE=$(getprop ro.product.device 2>/dev/null)
MODEL=$(getprop ro.product.model 2>/dev/null)
ui_print "- Device: $MODEL ($DEVICE)"
case "$DEVICE" in
    camellia|zircon|malachite|garnet) ;;
    *)
        ui_print "! WARNING: Unsupported device: $DEVICE"
        ui_print "  Optimized for: camellia (Poco X7), zircon (Redmi Note 14 Pro 5G)"
        ui_print "  Continuing install — some tweaks may not apply."
        ;;
esac

# ── Root manager detection ─────────────────────────────────────
# Detect Magisk: check binary first, then module dir
if [ -f "/data/adb/magisk/magisk" ] || command -v magisk >/dev/null 2>&1; then
    ROOT_MANAGER="magisk"
    MODULE_BASE="/data/adb/modules"
# Detect KernelSU: ksud binary path (official location)
elif [ -f "/data/adb/ksud" ] || [ -f "/data/adb/ksu/bin/ksud" ] || \
     [ "$(getprop ro.kernelsu.version 2>/dev/null)" != "" ]; then
    if [ -f "/data/adb/ksu/next" ] || [ "$(getprop ro.kernelsu.next 2>/dev/null)" != "" ]; then
        ROOT_MANAGER="ksu_next"
    else
        ROOT_MANAGER="ksu"
    fi
    MODULE_BASE="/data/adb/modules"
    # KSU uses /data/adb/modules on newer builds, fallback to ksu/modules
    [ -d "/data/adb/ksu/modules" ] && MODULE_BASE="/data/adb/ksu/modules"
# Detect APatch
elif [ -f "/data/adb/apd" ] || [ -d "/data/adb/ap" ]; then
    ROOT_MANAGER="apatch"
    MODULE_BASE="/data/adb/ap/modules"
else
    ROOT_MANAGER="unknown"
    MODULE_BASE="/data/adb/modules"
fi
ui_print "- Root: $ROOT_MANAGER ($MODULE_BASE)"

# Cache for service.sh to use at runtime
echo "$ROOT_MANAGER" > /data/adb/gopt_root_manager
echo "$MODULE_BASE"  > /data/adb/gopt_module_base

# ── ROM detection ──────────────────────────────────────────────
MIUI_VER=$(getprop ro.miui.ui.version.name 2>/dev/null)
HYPER_VER=$(getprop ro.hyperos.version 2>/dev/null)
if [ -n "$MIUI_VER" ] || [ -n "$HYPER_VER" ]; then
    ui_print "- ROM: MIUI / HyperOS"
else
    ui_print "- ROM: PixelOS / AOSP"
fi

# ── SoC detection ─────────────────────────────────────────────
CHIPSET=$(grep -i 'hardware' /proc/cpuinfo | uniq | cut -d ':' -f2 | sed 's/^[ \t]*//')
[ -z "$CHIPSET" ] && CHIPSET="$(getprop ro.board.platform) $(getprop ro.hardware)"
case "$(echo "$CHIPSET" | tr '[:upper:]' '[:lower:]')" in
    *mt*) ui_print "- SoC: MediaTek detected" ;;
    *sm*|*qcom*) ui_print "- SoC: Snapdragon detected" ;;
    *) ui_print "- SoC: $CHIPSET" ;;
esac

unzip -o "$ZIPFILE" 'service.sh'      -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'post-fs-data.sh' -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'uninstall.sh'    -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'module.prop'     -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'webroot/*'       -d "$MODPATH" >&2
unzip -o "$ZIPFILE" 'system/*'        -d "$MODPATH" >&2

set_perm "$MODPATH/service.sh"             root root 0755
set_perm "$MODPATH/post-fs-data.sh"        root root 0755
set_perm "$MODPATH/uninstall.sh"           root root 0755
set_perm "$MODPATH/system/bin/dex2oat_opt" root root 0755

# Config: preserve existing values on upgrade, append missing keys
if [ -f /data/adb/gopt_config ]; then
    grep -q "^tcp="          /data/adb/gopt_config || echo "tcp=on"          >> /data/adb/gopt_config
    grep -q "^dns="          /data/adb/gopt_config || echo "dns=on"          >> /data/adb/gopt_config
    grep -q "^dex2oat="      /data/adb/gopt_config || echo "dex2oat=on"      >> /data/adb/gopt_config
    grep -q "^disabletrace=" /data/adb/gopt_config || echo "disabletrace=off" >> /data/adb/gopt_config
    grep -q "^walttunes="    /data/adb/gopt_config || echo "walttunes=off"   >> /data/adb/gopt_config
    grep -q "^sfltuning="    /data/adb/gopt_config || echo "sfltuning=on"    >> /data/adb/gopt_config
    grep -q "^killlogd="     /data/adb/gopt_config || echo "killlogd=off"    >> /data/adb/gopt_config
    ui_print "- Config: migrated (existing settings preserved)"
else
    cat > /data/adb/gopt_config << 'CONF'
mode=balanced
render=default
refresh=default
thermal=enable
underclock=off
hamada=on
dex2oat=on
tcp=on
dns=on
disabletrace=off
walttunes=off
sfltuning=on
killlogd=off
CONF
    ui_print "- Config: created with defaults"
fi

[ ! -f /data/adb/gopt_gamelist ] && touch /data/adb/gopt_gamelist

ui_print "- PPM / EAS / CCI / DDR: enabled (MTK Dimensity)"
ui_print "- GPU: gpufreqv2 + GED + FPSGO + power limiter bypass"
ui_print "- Scheduler: sched_lib + CFS latency + stune"
ui_print "- TCP: BBR + FQ qdisc + buffer tuning"
ui_print "- DNS: Cloudflare 1.1.1.1 (DoT)"
ui_print "- SFL: SurfaceFlinger phase offset tuning"
ui_print "- Advanced: Trace disable / WALT / thermal kill support"
ui_print "- Games: 50+ pre-loaded for QuartzAI"
ui_print "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
