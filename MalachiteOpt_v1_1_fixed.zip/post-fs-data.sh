#!/system/bin/sh
# MalachiteOpt v1.1 — post-fs-data.sh
# Runs early in boot (before service.sh), data partition mounted

# ── ZRAM — Force lz4 compression (faster for MTK Dimensity chips) ─────────────
# Must swapoff first; comp_algorithm is read-only while swap is active
ZRAM=/sys/block/zram0
if [ -b "$ZRAM" ]; then
    swapoff /dev/block/zram0 2>/dev/null || true
    echo 1 > "${ZRAM}/reset" 2>/dev/null || true
    echo lz4 > "${ZRAM}/comp_algorithm" 2>/dev/null || true
    swapon /dev/block/zram0 2>/dev/null || true
fi

# ── CPUSET — Prioritize top-app on Big cores (cpu4-7, A78) ───────────────────
echo 0-3 > /dev/cpuset/background/cpus        2>/dev/null || true
echo 0-3 > /dev/cpuset/system-background/cpus 2>/dev/null || true
echo 4-7 > /dev/cpuset/top-app/cpus           2>/dev/null || true
echo 0-7 > /dev/cpuset/foreground/cpus        2>/dev/null || true

# ── VM — Early baseline tweaks (overridden by service.sh after boot) ──────────
echo 60 > /proc/sys/vm/swappiness  2>/dev/null || true
echo 10 > /proc/sys/vm/dirty_ratio 2>/dev/null || true
